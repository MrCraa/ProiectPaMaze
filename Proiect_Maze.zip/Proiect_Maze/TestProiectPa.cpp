#include <SFML/Graphics.hpp>
#include <vector>
#include <stack>
#include <ctime>
#include <algorithm>
#include <optional>
#include <random>
#include <iostream>

const int CELL_SIZE = 40;
const int GRID_WIDTH = 15;
const int GRID_HEIGHT = 15;

struct Question {
    std::string text;
    std::string options[3];
    int correctOption;
    std::string hint;
};

struct Cell {
    int x, y;
    bool visited = false;
    bool walls[4] = {true, true, true, true};
    bool hasHint = false;
    bool hasQuestion = false;
    int parentIdx = -1;
};

int getIndex(int x, int y) {
    if (x < 0 || y < 0 || x >= GRID_WIDTH || y >= GRID_HEIGHT) return -1;
    return x + y * GRID_WIDTH;
}

int main() {
    // Setăm fereastra să nu poată fi redimensionată pentru stabilitate
    sf::RenderWindow window(sf::VideoMode({GRID_WIDTH * CELL_SIZE, GRID_HEIGHT * CELL_SIZE + 260}), 
                            "Maze Mastery - Module 3", sf::Style::Titlebar | sf::Style::Close);
    window.setFramerateLimit(60);
    srand(static_cast<unsigned int>(time(0)));

    sf::Font font;
    // MODIFICARE CRITICĂ: Căutăm fontul în folderul local al jocului
    if (!font.openFromFile("arial.ttf")) {
        // Dacă nu găsim arial.ttf lângă .exe, încercăm fontul de sistem (doar ca backup)
        if (!font.openFromFile("C:/Windows/Fonts/arial.ttf")) {
            std::cerr << "Eroare: Nu am gasit arial.ttf in folderul jocului!" << std::endl;
            // Nu închidem programul, dar textul nu va fi vizibil
        }
    }

    std::vector<Cell> cells;
    for (int y = 0; y < GRID_HEIGHT; y++) {
        for (int x = 0; x < GRID_WIDTH; x++) cells.push_back({x, y});
    }

    std::stack<int> stack;
    cells[0].visited = true; stack.push(0);
    while (!stack.empty()) {
        int currIdx = stack.top();
        std::vector<int> neighbors;
        int dx[] = {0, 1, 0, -1}, dy[] = {-1, 0, 1, 0};
        for (int i = 0; i < 4; i++) {
            int nIdx = getIndex(cells[currIdx].x + dx[i], cells[currIdx].y + dy[i]);
            if (nIdx != -1 && !cells[nIdx].visited) neighbors.push_back(i);
        }
        if (!neighbors.empty()) {
            int dir = neighbors[rand() % neighbors.size()];
            int nextIdx = getIndex(cells[currIdx].x + dx[dir], cells[currIdx].y + dy[dir]);
            cells[currIdx].walls[dir] = false;
            cells[nextIdx].walls[(dir + 2) % 4] = false;
            cells[nextIdx].visited = true;
            cells[nextIdx].parentIdx = currIdx;
            stack.push(nextIdx);
        } else stack.pop();
    }

    std::vector<int> mainPath;
    int pathTracker = getIndex(GRID_WIDTH - 1, GRID_HEIGHT - 1);
    while (pathTracker != -1) {
        mainPath.push_back(pathTracker);
        pathTracker = cells[pathTracker].parentIdx;
    }
    std::reverse(mainPath.begin(), mainPath.end());

    int qCount = 0;
    for (size_t i = 6; i < mainPath.size() - 2 && qCount < 10; i++) {
        int cellIdx = mainPath[i];
        int openWalls = 0;
        for (int w = 0; w < 4; w++) if (!cells[cellIdx].walls[w]) openWalls++;
        if (openWalls >= 3) {
            cells[cellIdx].hasQuestion = true;
            cells[mainPath[i - 4]].hasHint = true;
            qCount++;
            i += 5; 
        }
    }

    if (qCount < 10) {
        for (size_t i = 10; i < mainPath.size() - 5 && qCount < 10; i += 7) {
            if (!cells[mainPath[i]].hasQuestion) {
                cells[mainPath[i]].hasQuestion = true;
                cells[mainPath[i-3]].hasHint = true;
                qCount++;
            }
        }
    }

    std::vector<Question> questions = {
        {"What does a Web Developer do?", {"Hardware", "Build sites", "Print"}, 1, "Web developers build and maintain websites."},
        {"Front-end focuses on:", {"Servers", "User Visuals", "Wires"}, 1, "Front-end is what the user sees."},
        {"Back-end handles:", {"Colors", "Server & Logic", "Fonts"}, 1, "Back-end is the server-side logic."},
        {"Full-stack means:", {"Both Sides", "Only CSS", "Hardware"}, 0, "Full-stack handles both Front and Back."},
        {"What is HTML?", {"Image", "Structure", "Style"}, 1, "HTML is the skeleton of the website."},
        {"CSS is used for:", {"Data", "Layout & Style", "Logic"}, 1, "CSS makes the website look good."},
        {"JavaScript adds:", {"Static", "Interactivity", "Speed"}, 1, "JS adds dynamic behavior."},
        {"A CMS is:", {"Content Manager", "Memory", "GPU"}, 0, "CMS helps manage site content."},
        {"Web Frameworks:", {"Slow down", "Speed up dev", "Delete"}, 1, "Frameworks help you code faster."},
        {"API stands for:", {"Prog Interface", "Apple Pie", "Auto Ink"}, 0, "APIs allow apps to communicate."}
    };

    int pX = 0, pY = 0, qDone = 0;
    bool showQ = false, showH = false, gameWon = false, hReady = false;
    sf::Clock radarClock; bool rActive = false;

    sf::CircleShape player(10.f); player.setFillColor(sf::Color::Blue);
    sf::CircleShape hintP(8.f); hintP.setFillColor(sf::Color::Yellow);
    sf::RectangleShape rHigh({36.f, 36.f}); rHigh.setFillColor(sf::Color(255, 0, 0, 160));
    sf::RectangleShape uiBG({600.f, 260.f}); uiBG.setFillColor(sf::Color(240, 240, 240));
    uiBG.setPosition({0.f, 600.f});

    while (window.isOpen()) {
        while (const std::optional event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) window.close();
            if (!gameWon) {
                if (const auto* kp = event->getIf<sf::Event::KeyPressed>()) {
                    if (kp->code == sf::Keyboard::Key::R) { rActive = true; radarClock.restart(); }
                    
                    if (!showQ && !showH) {
                        int cur = getIndex(pX, pY);
                        if (cur != -1) {
                            if (kp->code == sf::Keyboard::Key::Up && !cells[cur].walls[0]) pY--;
                            else if (kp->code == sf::Keyboard::Key::Right && !cells[cur].walls[1]) pX++;
                            else if (kp->code == sf::Keyboard::Key::Down && !cells[cur].walls[2]) pY++;
                            else if (kp->code == sf::Keyboard::Key::Left && !cells[cur].walls[3]) pX--;
                        }

                        int nxt = getIndex(pX, pY);
                        if (nxt != -1 && nxt != cur) {
                            if (cells[nxt].hasHint) { showH = true; cells[nxt].hasHint = false; }
                            else if (cells[nxt].hasQuestion && hReady) { showQ = true; }
                        }
                        if (pX == GRID_WIDTH-1 && pY == GRID_HEIGHT-1 && qDone >= qCount) gameWon = true;
                    } 
                    else if (showH && kp->code == sf::Keyboard::Key::Enter) { showH = false; hReady = true; }
                    else if (showQ) {
                        int c = -1;
                        if (kp->code == sf::Keyboard::Key::Num1) c = 0;
                        else if (kp->code == sf::Keyboard::Key::Num2) c = 1;
                        else if (kp->code == sf::Keyboard::Key::Num3) c = 2;
                        if (c == questions[qDone].correctOption) {
                            int qIdx = getIndex(pX, pY);
                            if (qIdx != -1) cells[qIdx].hasQuestion = false;
                            showQ = false; hReady = false; qDone++;
                        }
                    }
                }
            }
        }

        if (rActive && radarClock.getElapsedTime().asSeconds() > 3.f) rActive = false;
        window.clear(sf::Color::White);

        sf::RectangleShape s({40,40}), f({40,40}); 
        s.setFillColor(sf::Color(200,255,200)); f.setFillColor(sf::Color(255,200,200));
        s.setPosition({0.f,0.f}); f.setPosition({(GRID_WIDTH-1)*40.f, (GRID_HEIGHT-1)*40.f});
        window.draw(s); window.draw(f);

        for (const auto& cell : cells) {
            float x = cell.x * 40.f, y = cell.y * 40.f;
            if (rActive && cell.hasQuestion) { rHigh.setPosition({x+2.f, y+2.f}); window.draw(rHigh); }
            if (cell.hasHint) { hintP.setPosition({x+12.f, y+12.f}); window.draw(hintP); }
            sf::RectangleShape line; line.setFillColor(sf::Color::Black);
            if (cell.walls[0]) { line.setSize({40,2}); line.setPosition({x,y}); window.draw(line); }
            if (cell.walls[1]) { line.setSize({2,40}); line.setPosition({x+40,y}); window.draw(line); }
            if (cell.walls[2]) { line.setSize({40,2}); line.setPosition({x,y+40}); window.draw(line); }
            if (cell.walls[3]) { line.setSize({2,40}); line.setPosition({x,y}); window.draw(line); }
        }

        player.setPosition({pX*40.f+10.f, pY*40.f+10.f}); window.draw(player);
        window.draw(uiBG);
        sf::Text st(font, "Tests: " + std::to_string(qDone) + "/" + std::to_string(qCount) + " | R: Radar", 16);
        st.setFillColor(sf::Color::Black); st.setPosition({10, 610}); window.draw(st);

        if (showH) {
            sf::Text t(font, "LEARNING HINT:\n" + questions[qDone].hint + "\nPress [Enter] to reach the intersection.", 15);
            t.setFillColor(sf::Color(120,60,0)); t.setPosition({10, 650}); window.draw(t);
        } else if (showQ) {
            sf::Text t(font, "INTERSECTION TEST:\n" + questions[qDone].text + "\n1: " + questions[qDone].options[0] + "  2: " + questions[qDone].options[1] + "  3: " + questions[qDone].options[2], 14);
            t.setFillColor(sf::Color::Red); t.setPosition({10, 650}); window.draw(t);
        } else if (gameWon) {
            sf::Text win(font, "MAZE ESCAPED! Module 3 Mastery Complete.", 18);
            win.setFillColor(sf::Color::Blue); win.setPosition({10, 650}); window.draw(win);
        }
        window.display();
    }
    return 0;
}